export const environment = {
  production: true,
  api_url: "//shrek.fr/api",
};
