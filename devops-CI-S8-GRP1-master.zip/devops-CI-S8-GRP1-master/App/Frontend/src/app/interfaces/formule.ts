export interface Formule {
  nom_formule: string,
  description: string,
  vcores: number,
  ram: string,
  disque: string,
  bande_passante: number,
  prix: number
}
