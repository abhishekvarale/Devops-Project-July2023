# devops-CI-S8-GRP1
This is the repository of group 1 of the SE1 class

# Team

- Bouthayna ATIK
- Samuel BADER
- Nicolas CRESSEAUX
- Tristan FIEVET
- Enzo FILANGI
- Paul GODIN
- Carlos MADRUGA
- Alex SALMON
